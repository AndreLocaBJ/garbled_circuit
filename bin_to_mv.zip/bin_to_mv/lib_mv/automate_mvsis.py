import os

def synth(working_dir):  
    with open('./synth.mvsis', 'w') as file:
        for ele in os.listdir('{}/blif'.format(working_dir)):
            if ele.endswith('.blif'):
                file.write('read_blif {}/blif/{}\n'.format(working_dir,ele))
                file.write('sweep\n')
                file.write('eliminate -l 1\n')
                file.write('simplify -m nocomp\n')
                file.write('eliminate -l 1\n')
                file.write('sweep\n')
                file.write('eliminate -l 5\n')
                file.write('simplify\n')
                file.write('resub\n')
                file.write('fxu\n')
                file.write('resub\n')
                file.write('sweep\n')
                file.write('eliminate -l 1\n')
                file.write('sweep\n')
                file.write('fullsimp -m nocomp\n')
                file.write('write_blif_mv {}/blif/synth/{}.blif\n\n'.format(working_dir, ele.split('.')[0]))

                file.write('read_blif_mv {}/blfmv/{}.blfmv\n'.format(working_dir, ele.split('.')[0]))
                file.write('sweep\n')
                file.write('eliminate\n')
                file.write('simplify\n')
                file.write('fullsimp\n')
                file.write('simplify\n')
                file.write('sweep\n')
                file.write('eliminate\n')
                file.write('write_blif_mv {}/blfmv/synth/{}.blifmv\n\n'.format(working_dir, ele.split('.')[0]))

def pla_to_blif(working_dir):
    for ele in os.listdir('{}/pla'.format(working_dir)):
        with open('./pla_to_blif.mvsis', 'a') as file:
            file.write('read_pla {}/pla/{}\n'.format(working_dir,ele))
            file.write('write_blif_mv {}/blif/{}.blif\n\n'.format(working_dir, ele.split('.')[0]))